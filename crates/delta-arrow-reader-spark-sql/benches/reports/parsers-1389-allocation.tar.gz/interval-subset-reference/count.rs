use arrow::array::{Array, Int32Array, Int64Array};
use arrow::ipc::reader::StreamReader;
use std::collections::BTreeSet;
use std::fs::File;

fn main() {
    let path = std::env::args().nth(1).expect("full native Arrow export");
    let stream = StreamReader::try_new(File::open(path).unwrap(), None).unwrap();
    let mut count = 0;
    let mut keys = BTreeSet::new();
    let mut null_rows = 0;
    for batch in stream {
        let batch = batch.unwrap();
        let order = batch.column(0).as_any().downcast_ref::<Int64Array>().unwrap();
        let line = batch.column(1).as_any().downcast_ref::<Int32Array>().unwrap();
        assert_eq!(order.null_count() + line.null_count(), 0);
        count += batch.num_rows();
        for (key, number) in order.values().iter().zip(line.values()) {
            if (1..=8192).contains(key) {
                assert!((1..=7).contains(number));
                assert!(keys.insert((*key, *number)));
                if key % 97 == 0 {
                    null_rows += 1;
                }
            }
        }
    }
    assert_eq!(count, 6_001_215);
    assert!(!keys.is_empty() && keys.len() <= 8192 * 7);
    println!(
        "{{\"source_rows\":{count},\"interval_rows\":{},\"null_rows\":{null_rows},\"min_order_key\":1,\"max_order_key\":8192,\"keys_unique\":true,\"line_numbers_in_1_to_7\":true}}",
        keys.len()
    );
}
