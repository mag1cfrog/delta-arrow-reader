use sail_sql_analyzer::literal::interval::IntervalValue;
use sail_sql_analyzer::parser::{parse_date, parse_interval};
use std::hint::black_box;

fn main() {
    let mode = std::env::args().nth(1).expect("date or interval");
    let mut prior = 0;
    for completed in [0, 128, 256, 512, 1024, 2048, 4096] {
        for _ in prior..completed {
            match mode.as_str() {
                "date" => {
                    black_box(parse_date(black_box("1996-2-9")).expect("valid date"));
                }
                "interval" => {
                    let value = parse_interval(black_box("2 months")).expect("valid interval");
                    assert!(matches!(black_box(value), IntervalValue::YearMonth { months: 2, .. }));
                }
                _ => panic!("expected date or interval"),
            }
        }
        prior = completed;
        println!("{mode} completed={completed}");
        let status = std::fs::read_to_string("/proc/self/status").expect("process status");
        for row in status.lines().filter(|line| {
            line.starts_with("VmRSS:") || line.starts_with("VmSize:") || line.starts_with("VmHWM:")
        }) {
            println!("{row}");
        }
    }
}
