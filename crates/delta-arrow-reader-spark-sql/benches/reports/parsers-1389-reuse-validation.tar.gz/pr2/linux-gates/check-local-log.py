import json
from pathlib import Path
import re
import sys

root = Path(__file__).parent
platform, filename, reference_path = sys.argv[1:]
raw = Path(filename).read_text(errors='strict')
clean = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', raw)
clean = re.sub(r'^\d{4}-\d\d-\d\dT\S+Z ', '', clean, flags=re.M)
Path(filename).with_name(platform + '.log').write_text(clean)
# Cargo progress is stderr; libtest results are stdout. Pair their ordered
# groups after parsing, because GitHub can interleave a next header early.
headers = []
for line in clean.splitlines():
    if match := re.search(r'Running .+[/\\]([^/\\ ()]+)-[a-f0-9]{16}(?:\.exe)?\)', line):
        headers.append('binary:' + match[1])
    elif match := re.search(r'Doc-tests (\S+)', line):
        headers.append('doc:' + match[1])
group_index = -1
tests, summaries = [], []
for line in clean.splitlines():
    if re.match(r'running \d+ tests?$', line):
        group_index += 1
    elif match := re.match(r'test (.+) \.\.\. (ok|FAILED|ignored)(?:,.*)?$', line):
        group = headers[group_index]
        name = match[1].replace('\\', '/') if group.startswith('doc:') else match[1]
        tests.append((group, name, match[2]))
    elif match := re.match(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', line):
        summaries.append((headers[group_index], *map(int, match.groups())))
assert len(headers) == group_index + 1 == len(summaries)
reference = json.loads(Path(reference_path).read_text())
assert len(tests) == len(set(tests)), 'Duplicate named outcome'
actual = {(group, name): outcome for group, name, outcome in tests}
prior = {(group, name): outcome for group, name, outcome in reference['tests']}
changed = [(key, outcome, actual.get(key)) for key, outcome in prior.items() if actual.get(key) != outcome]
assert not changed, changed
assert all(item[2] != 'FAILED' for item in tests)
counts = [sum(x[i] for x in summaries) for i in range(1, 6)]
assert counts[1] == counts[3] == counts[4] == 0, counts
new_tests = [item for item in tests if item[:2] not in prior]
assert counts[0] + counts[2] == len(tests)
result = dict(platform=platform, passed=counts[0], failed=counts[1], ignored=counts[2],
              measured=counts[3], filtered_out=counts[4], summaries=len(summaries),
              named_outcomes=len(tests), prior_outcomes_unchanged=len(prior), new_named_outcomes=new_tests,
              ignored_tests=[x for x in tests if x[2] == 'ignored'])
(root / (platform + '-inventory.json')).write_text(json.dumps(dict(tests=sorted(tests), summaries=summaries), indent=2) + '\n')
(root / (platform + '-results.json')).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
