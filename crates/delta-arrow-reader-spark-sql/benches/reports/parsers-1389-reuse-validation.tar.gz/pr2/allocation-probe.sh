set -eu
set -o pipefail
dar_root=$(cd "$(dirname "$0")/.." && pwd)
dar_alloc="$dar_root/pr2/allocation-diagnostic"
mkdir "$dar_alloc"
dar_target=/home/hanbo/.cache/delta-arrow-reader/costs-168-2026-11-19/release/deps
dar_analyzer=$(jq -rc 'select(.reason == "compiler-artifact" and .target.name == "sail_sql_analyzer") | .filenames[] | select(endswith(".rlib"))' "$dar_root/pr2-preflight-build/cargo.jsonl")
dar_original_probe="$dar_root/allocation-diagnostic/probe.rs"
test -f "$dar_analyzer" && test -f "$dar_original_probe"
sha256sum "$dar_analyzer" "$dar_original_probe" > "$dar_alloc/input.sha256"
rustc +1.96.0 --edition 2024 -O -L "dependency=$dar_target" --extern "sail_sql_analyzer=$dar_analyzer" "$dar_original_probe" -o "$dar_alloc/probe" > "$dar_alloc/build.log" 2>&1
for dar_case in date interval; do
    timeout 60s prlimit --as=2147483648 taskset -c 2,3,4,5 "$dar_alloc/probe" "$dar_case" | tee "$dar_alloc/$dar_case.log"
done
