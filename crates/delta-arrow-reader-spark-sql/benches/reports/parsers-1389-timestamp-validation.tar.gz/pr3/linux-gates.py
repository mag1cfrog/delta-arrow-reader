"""Run serial full-workspace Linux gates and bind the exact tested source."""
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

root = Path('/home/hanbo/repo/delta-arrow-reader-costs-168')
workspace = root / 'crates/delta-arrow-reader-spark-sql'
evidence = Path(__file__).resolve().parent
output = evidence / 'linux-gates'
output.mkdir()
base = 'bc5ac56fc6630c76dadbba6582f704616e22eae0'
env = dict(CARGO_TARGET_DIR='/home/hanbo/.cache/delta-arrow-reader/costs-168-2026-11-19',CARGO_BUILD_JOBS='2')
git = lambda *args: subprocess.check_output(['git',*args],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')==base
modified = set(git('diff','--name-only').splitlines()+git('ls-files','--others','--exclude-standard').splitlines())
assert len(modified)==6
assert all(p.startswith('crates/delta-arrow-reader-spark-sql/') for p in modified)
sha = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
hashes = {p:sha(root/p) for p in sorted(modified)}
freeze = evidence.parent/'protected-pr1-assets.json'
historical = evidence.parent.parent/'protected-historical-assets.json'
for manifest in [freeze,historical,evidence/'protected-pr2-assets.json']:
    for asset in json.loads(manifest.read_text())['files']:
        if asset['path']=='crates/delta-arrow-reader-spark-sql/benches/parsers/run.py':
            assert manifest!=historical
            continue
        assert sha(root/asset['path'])==asset['sha256'],asset['path']
commands = {
    'format':['cargo','+1.96.0','fmt','--all','--','--check'],
    'clippy':['cargo','+1.96.0','clippy','--locked','-p','delta-arrow-reader-spark-sql','--all-targets','--no-deps','--','-D','warnings'],
    'workspace':['cargo','+1.96.0','test','--locked','--workspace'],
}
intent={'source_commit':base,'candidate_files':hashes,'cwd':str(workspace),'environment':env,'commands':commands}
(output/'intent.json').write_text(json.dumps(intent,indent=2)+'\n')
subprocess.run(['git','diff','--check'],cwd=root,check=True)
results = {}
for name, command in commands.items():
    started = time.monotonic()
    with (output/f'{name}.log').open('x') as log:
        run = subprocess.run(command,cwd=workspace,env=os.environ | env,stdout=log,stderr=subprocess.STDOUT)
    results[name] = {'exit_code':run.returncode,'elapsed_seconds':time.monotonic()-started}
    assert hashes == {p:sha(root/p) for p in sorted(modified)}
    assert git('rev-parse','HEAD')==base
    (output/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(name,results[name],flush=True)
    run.check_returncode()
