import hashlib,json,pathlib,re
p=pathlib.Path('/home/hanbo/.local/share/delta-arrow-reader-review/measurements-2026-11-18/1381')
results=json.loads((p/'native-tests/results.json').read_text())
assert [r['suite'] for r in results]==['core-direct','core-datafusion','cli']
suites={}
for result in results:
    suite=result['suite']; path=p/'native-tests'/suite/'stdout.log';text=path.read_text()
    outcomes=[dict(name=m[1],outcome=m[2]) for m in re.finditer(r'^test (.+) \.\.\. (ok|FAILED|ignored)(?:, .*)?$',text,re.M)]
    groups=[dict(outcome=m[1],passed=int(m[2]),failed=int(m[3]),ignored=int(m[4]),measured=int(m[5]),filtered_out=int(m[6])) for m in re.finditer(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text,re.M)]
    totals={k:sum(g[k] for g in groups) for k in ['passed','failed','ignored','measured','filtered_out']}
    assert all(sum(o['outcome']==outcome for o in outcomes)==totals[key] for outcome,key in [('ok','passed'),('FAILED','failed'),('ignored','ignored')]),suite
    suites[suite]=dict(command=result['command'],exit_code=result['exit_code'],status=result['status'],totals=totals,result_groups=len(groups),failed_names=[o['name'] for o in outcomes if o['outcome']=='FAILED'],named_outcomes=outcomes,groups=groups,stdout_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),stderr_sha256=hashlib.sha256((path.parent/'stderr.log').read_bytes()).hexdigest())
output=dict(source_commit='b0c554143c686d44c7fe9897350b24a0a3cc1669',counts_are_per_command_not_unique_across_commands=True,suites=suites)
(p/'linux-native-results.json').write_text(json.dumps(output,indent=2)+'\n')
for name,result in suites.items(): print(name,result['exit_code'],result['totals'],result['result_groups'],result['failed_names'])
