import json,pathlib,shutil,subprocess,sys
here=pathlib.Path('/home/hanbo/repo/delta-arrow-reader-measurements/crates/delta-arrow-reader-spark-sql/benches/footprint')
sys.path.insert(0,str(here))
import build
p=pathlib.Path('/home/hanbo/.local/share/delta-arrow-reader-review/measurements-2026-11-18/1381')
request_path=p/'attribution-correction-request.json'
assert build.digest(request_path)=='5e495025dc5ffbb2ce81b0d2635e80492e1b48fb917c8a60c8fcfc614bf6e0a9'
request=json.loads(request_path.read_text())
assert request['authorized'] and request['maximum_invocations']==1 and not request['collect_elapsed_performance']
results=json.loads((p/'native-tests/results.json').read_text())
assert [r['suite'] for r in results]==['core-direct','core-datafusion','cli']
assert all(r['status']=='completed' for r in results)
authorization=build.read_measurement_authorization()
linked=json.loads((p/'clean-builds/builds.json').read_text())['builds']['linked']
original=pathlib.Path(linked['binary']);assert build.digest(original)==request['sealed_original_sha256']
destination=p/'linked-attribution-matched';destination.mkdir()
(destination/'authorization.json').write_text(json.dumps(authorization,indent=2)+'\n')
shutil.copyfile(request_path,destination/'correction-request.json')
try:
    build.checkout_source('linked');build.assert_clean_source('linked')
    assert build.SOURCES['builds']['linked']==request['source_commit']
    binary=pathlib.Path(linked['target_directory'])/build.SCHEDULE['target']/'release/dar'
    before=dict(sha256=build.digest(binary),bytes=binary.stat().st_size)
    result=build.run_command(request['command'],destination/'cargo-bloat',request['timeout_seconds'],build.build_environment('1.96.0'),timed=False)
    assert result['status']=='completed' and result['exit_code']==0,'Preserve the failed single correction; no further attempt'
    build.assert_clean_source('linked');assert build.digest(original)==request['sealed_original_sha256']
    immutable=destination/'dar-attribution';shutil.copyfile(binary,immutable);immutable.chmod(0o555)
    after=dict(binary=str(immutable),sha256=build.digest(immutable),bytes=immutable.stat().st_size)
    receipt=dict(request_sha256=build.digest(request_path),analysis_script_sha256=build.digest(__file__),source_commit=request['source_commit'],source_tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=build.SCRATCH,text=True).strip(),cargo_bloat_version=subprocess.check_output(['rustup','run','1.96.0','cargo','bloat','--version'],text=True).strip(),tool_binary_before=before,tool_binary_after=after,original_binary_sha256=build.digest(original),full_original_binary_match=after['sha256']==build.digest(original),command_receipt=result,protocol_deviation=request['protocol_deviation'])
    (destination/'attribution.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))
finally:
    build.restore_scratch_branch()
